Thank you for downloading my fonts^^


NON-COMMERCIAL USE
I consider �non-commercial� any school, research or charity project where you (or your client) are not earning money. Any other use is considered commercial.
 
If you�re going to use my fonts for non commercial projects, just write me a mail (nuraisyahamalia1729@gmail.com) telling me you�re using it.
If possible, include what for, and if you�re feeling generous, I�d love to see a sample of my fonts in action!

COMMERCIAL USE
For commercial use please donate via Paypal! (nuraisyahamalia1729@gmail.com)

The PayPal receipt proves the commercial license.

OR DOWNLOAD HERE :
https://www.creativefabrica.com/ref/369973

I recommend the donation sum is what you feel the font is worth to you and what you feel is right for what you�re getting from the fonts � I make less from doing this than you might think!

PLEASE
don�t sell my fonts or claim it as your own; don�t edit or rename my fonts; don�t redistribute my fonts.

Thank you for your support ^^ 